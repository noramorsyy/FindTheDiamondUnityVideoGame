using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Enderman : MonoBehaviour
{
    Transform target;
    Transform myTarget;
    public float MovementSpeed;
    public float TimeToGetAngry;
    float timeStamp;
    bool looking = false;
    bool myVariable = false;
    bool angry = false;

    void Start()
    {
        target = GameObject.FindWithTag("Player").transform;
        myTarget = this.transform;
        IsLookedAtByTarget();
    }

    void OnTriggerEnter(Collider playerDetected)
    {
        if (playerDetected.CompareTag("Player"))
        {
            myVariable = true;
        }
    }

    void Update()
    {
        IsLookedAtByTarget();
        Vector3 targetPosition = new Vector3(target.position.x, transform.position.y, target.position.z);
        transform.LookAt(targetPosition);
        if (IsLookedAtByTarget())
        {
            Debug.Log("Player is looking at enemy.");
            timeStamp = Time.time;
            if(timeStamp >= TimeToGetAngry)
            {
                angry = true;
            }
        }
        else if (angry)
        {
            Debug.Log("Player is not looking at enemy.");
            transform.position += (targetPosition - transform.position).normalized * MovementSpeed * Time.deltaTime;
        }
    }

    bool IsLookedAtByTarget()
    {
        Vector3 toEnderman = (this.transform.position - target.transform.position).normalized;
        if (Vector3.Dot(toEnderman, -target.position) < 0)
        {
            
            return true;
        }
        else
        {
             Debug.Log("Player is not looking at enemy.");
            return false;
        }
    }
}
