using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Creeper : MonoBehaviour
{
    public int radius;
    void OnTriggerEnter(Collider playerDetected)
    {

        if (playerDetected.CompareTag("Player"))
        {
            Collider[] hitColliders = Physics.OverlapSphere(transform.position, radius);
            Destroy(this.gameObject); //Destroys Creeper

            foreach (Collider collider in hitColliders)
            {
                    Block block = collider.GetComponent<Block>();
                    if (block)
                        block.DestroyBlock();
            }

        } 
    }

}
