using UnityEngine;
using UnityEngine.SceneManagement;

public class Board : MonoBehaviour
{
    public int Size;
    public int Depth;
    public Camera Camera;
    public GameObject Block;
    public GameObject Diamond;
    public GameObject DarkBlock;
    public GameObject DestroyBlockParticleSystem;
    public string SelectableTag = "Selectable";
    public string DiamondTag = "diamond";


    void Start()
    {
        CreateBoard();
        CreateDiamond();
        PlaceCamera();
    }

    // --------------------------------------------------------------------

    private void CreateBoard()
    {
        Depth = 0 - Depth;
        for(int i = 0; i < Size; i++)
        {
            for(int y = 0; y < Size; y++)
            {
                for (int j = Depth ; j < 0; j++)
                {
                    Instantiate(Block, new Vector3(i, 0, y), Quaternion.identity);
                    Instantiate(DarkBlock, new Vector3(i, j, y), Quaternion.identity);
                }
            }
        }


    }
    // --------------------------------------------------------------------

    private void PlaceCamera()
    {
        Camera.transform.position = new Vector3(Size / 2f - 0.5f, Size, -Size / 4f);
        Camera.transform.LookAt(new Vector3(Size / 2f - 0.5f, 0, Size / 2f));
    }

    // --------------------------------------------------------------------

    private void CreateDiamond()
    {
        var position = new Vector3(Random.Range(0, Size), 0, Random.Range(0, Size));
        Instantiate(Diamond, position, Quaternion.identity);
    }


    // --------------------------------------------------------------------


    private void Update()
    {
        var ray = Camera.ScreenPointToRay(Input.mousePosition);
        RaycastHit hit;
        if (Input.GetMouseButtonDown(0) && Physics.Raycast(ray, out hit))
        {
            var selection = hit.transform;
            if (selection.CompareTag(SelectableTag))
            {
                Instantiate(DestroyBlockParticleSystem, hit.point, Quaternion.identity);
                Destroy(hit.transform.gameObject);
            }

            if (selection.CompareTag(DiamondTag))
            {
                Debug.Log("Diamond Found!");
                SceneManager.LoadScene("PlayAgain");
            }
        }

    }

}
