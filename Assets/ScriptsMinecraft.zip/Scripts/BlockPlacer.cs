using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BlockPlacer : MonoBehaviour
{
    public GameObject Block;
    public GameObject DarkBlock;

    private void Update()
    {
        var ray = Camera.main.ScreenPointToRay(Input.mousePosition);
        RaycastHit hit;
        if (Input.GetKeyDown(KeyCode.H) && Physics.Raycast(ray, out hit))
        {
            var selection = hit.point;
            Instantiate(Block, selection, Quaternion.identity);
        }
        if (Input.GetKeyDown(KeyCode.J) && Physics.Raycast(ray, out hit))
        {
            var selection = hit.point;
            Instantiate(Block, selection, Quaternion.identity);
        }

    }
}
