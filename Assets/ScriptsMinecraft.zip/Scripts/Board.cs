using UnityEngine;

public class Board : MonoBehaviour
{
    public int Size;
    public int Depth;
    public GameObject Block;
    public GameObject Diamond;
    public GameObject DarkBlock;
    public GameObject CreeperBlock;
    public GameObject Enderman;
    public GameObject Grass;


    void Start()
    {
        CreateBoard();
        CreateDiamond();
        CreateCreeper();
        CreateEnderman();
    }

    // --------------------------------------------------------------------

    private void CreateBoard()
    {
        for(int i = 0; i < Size; i++)
        {
            for(int y = 0; y < Size; y++)
            {
                for (int j = 0 ; j < Depth; j++)
                {
                    if(j==0)
                    Instantiate(Grass, new Vector3(i, 0, y), Quaternion.identity);
                    else if((-1*j)==-1)
                    Instantiate(Block, new Vector3(i, -j , y), Quaternion.identity);
                    else
                    Instantiate(DarkBlock, new Vector3(i, -j, y), Quaternion.identity);
                }
            }
        }
    }

    // --------------------------------------------------------------------

    private void CreateDiamond()
    {
        var position = new Vector3(Random.Range(0, Size), 0, Random.Range(0, Size));
        Instantiate(Diamond, position, Quaternion.identity);
    }

    private void CreateCreeper()
    {
        var position = new Vector3(Random.Range(0, Size), 0.5f, Random.Range(0, Size));
        Instantiate(CreeperBlock, position, Quaternion.identity);
    }

    private void CreateEnderman()
    {
        var position = new Vector3(Random.Range(0, Size), 1f, Random.Range(0, Size));
        Instantiate(Enderman, position, Quaternion.identity);
    }
}
