using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Block : MonoBehaviour
{
    public GameObject DestroyBlockParticleSystem;

    public void DestroyBlock()
    {
        Destroy(this.gameObject);
        Instantiate(DestroyBlockParticleSystem, this.gameObject.transform.position, Quaternion.identity);
    }
}
