using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Creeper : MonoBehaviour
{

    void OnTriggerEnter(Collider playerDetected)
    {

        if (playerDetected.CompareTag("Player"))
        {
            int radius = 2;
            Collider[] hitColliders = Physics.OverlapSphere(transform.position, radius);
            Destroy(this.gameObject); //Destroys Creeper

            foreach (Collider collider in hitColliders)
            {
                    Block block = collider.GetComponent<Block>();
                    if (block)
                        block.DestroyBlock();
            }

        } 
    }

}
