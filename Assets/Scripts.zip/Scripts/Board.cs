
using UnityEngine;

public class Board : MonoBehaviour
{
    public int Size;
    public Camera Camera;
    public GameObject Block;
    public GameObject Diamond;
    

    void Start()
    {
        CreateBoard();
        CreateDiamond();
        PlaceCamera();
    }

    // --------------------------------------------------------------------

    private void CreateBoard()
    {
        // TODO - Create a board of blocks of Size X Size (use Instantiate)
        GameObject[,] grid = new GameObject[Size, Size];
        for(int i = 0; i < Size; i++)
        {
            for(int y = 0; y < Size; y++)
            {
                grid[i, y] = Instantiate(Block, new Vector3(i, 0, y), Quaternion.identity);
            }
        }
    }
    // --------------------------------------------------------------------

    private void PlaceCamera()
    {
        Camera.transform.position = new Vector3(Size / 2f - 0.5f, Size, -Size / 4f);
        Camera.transform.LookAt(new Vector3(Size / 2f - 0.5f, 0, Size / 2f));
    }

    // --------------------------------------------------------------------

    private void CreateDiamond()
    {
        // TODO - Select a random position and instantiate the diamond there 

        var position = new Vector3(Random.Range(0, Size), 0, Random.Range(0, Size));
        Instantiate(Diamond, position, Quaternion.identity);
    }


    // --------------------------------------------------------------------

    private void Update()
    {
        // TODO - Raycast when the player clicks and delete blocks 
    }
}
