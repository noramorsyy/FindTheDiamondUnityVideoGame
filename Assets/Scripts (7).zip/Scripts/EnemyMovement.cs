using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EnemyMovement : MonoBehaviour
{
    Transform target;
    public float MovementSpeed ;


    void Start()
    {
        target = GameObject.FindWithTag("Player").transform;
    }

    void Update()
    {
        //transform.LookAt(target);
        Vector3 targetPosition = new Vector3(target.transform.position.x, transform.position.y, target.transform.position.z);
        transform.LookAt(targetPosition);
        transform.position += (targetPosition - transform.position).normalized * MovementSpeed * Time.deltaTime;
    }

}
