using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class Fall : MonoBehaviour
{

    void Update()
    {
        if(this.transform.position.y < -6f)
        {
            SceneManager.LoadScene(SceneManager.GetActiveScene().name);
        }
    }
}
