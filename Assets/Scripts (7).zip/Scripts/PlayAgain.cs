using UnityEngine;
using UnityEngine.SceneManagement;

public class PlayAgain : MonoBehaviour
{
    public void Again()
    {
        SceneManager.LoadScene("DiamondGame");
    }
}
