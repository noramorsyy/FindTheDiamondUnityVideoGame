using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Enderman : MonoBehaviour
{
    Transform target;
    Transform endermanTarget;
    public float MovementSpeed;
    bool detected;

    void Start()
    {
        target = GameObject.FindWithTag("Player").transform;
        endermanTarget = GameObject.FindWithTag("enderman").transform;
    }

    void OnTriggerEnter(Collider playerDetected)
    {

        if (playerDetected.CompareTag("Player"))
        {
            Vector3 targetPosition = new Vector3(target.position.x, transform.position.y, target.position.z);
            transform.LookAt(targetPosition);
            Vector3 toTarget = (endermanTarget.position - target.position).normalized;

            if (Vector3.Dot(toTarget, transform.forward) <= 0)
            {
                Debug.Log("Player is looking at enemy.");
            }
            else
            {
                Debug.Log("Player is not looking at enemy.");
                detected = true;
            }
        }
    }

    void Update()
    {
        if (detected == true)
        {
            Vector3 targetPosition = new Vector3(target.position.x, transform.position.y, target.position.z);
            transform.LookAt(targetPosition);
            transform.position += (targetPosition - transform.position).normalized * MovementSpeed * Time.deltaTime;
        }
    }
}
