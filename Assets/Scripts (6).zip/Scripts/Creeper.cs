using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Creeper : MonoBehaviour
{

    void OnTriggerEnter(Collider playerDetected)
    {
        if (playerDetected.CompareTag("Player"))
        {
                int radius = 2;
                Collider[] hitColliders = Physics.OverlapSphere(transform.position, radius);

            foreach (Collider collider in hitColliders)
            {
                if(collider.tag == "Selectable")
                {
                    Destroy(collider.gameObject); //Destroys blocks
                    Destroy(this.gameObject); //Destroys Creeper
                }
                    
            }

        } 
    }

}
