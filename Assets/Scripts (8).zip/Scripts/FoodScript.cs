using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class FoodScript : MonoBehaviour
{

    public var eating = false;

    void OnTriggerEnter(Collider playerDetected)
    {

        if (playerDetected.CompareTag("Player"))
        { 
            public var eating = true;
        }
    }
}

