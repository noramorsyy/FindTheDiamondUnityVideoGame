using System.Collections;
using System.Collections.Generic;
using UnityEditor.PackageManager.Requests;
using UnityEngine;
using UnityEngine.UI;

public class BarFiller : MonoBehaviour
{
    public Image HungerBar;
    public bool hungry;
    public float waitTime = 40.0f;

    void Update()
    {
        if (hungry == true)
        {
            HungerBar.fillAmount -= 1.0f / waitTime * Time.deltaTime;
        }
    }


}
