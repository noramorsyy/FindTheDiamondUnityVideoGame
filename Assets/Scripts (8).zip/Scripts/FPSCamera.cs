using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class FPSCamera : MonoBehaviour
{
    private float Yaw = 0.0f, Pitch = 0.0f;
    private Rigidbody RigidBody;
    Camera PlayerCamera;
    [SerializeField] float WalkSpeed = 5.0f, Sensitivity = 2.0f;
    void Start()
    {
        PlayerCamera = Camera.main;
        Cursor.lockState = CursorLockMode.Locked;
        RigidBody = gameObject.GetComponent<Rigidbody>();

    }


    void Update()
    {
        if (Input.GetKey(KeyCode.Space) && Physics.Raycast(RigidBody.transform.position, Vector3.down, 1 + 0.001f)) 
        RigidBody.velocity = new Vector3(RigidBody.velocity.x, 5.0f, RigidBody.velocity.z);
        Look();
    }

    private void FixedUpdate()
    {
        Movement();
    }

    void Look()
    {
        Pitch -= Input.GetAxisRaw("Mouse Y") * Sensitivity;
        Pitch = Mathf.Clamp(Pitch, -90.0f, 90.0f);
        Yaw += Input.GetAxisRaw("Mouse X") * Sensitivity;
        PlayerCamera.transform.localRotation = Quaternion.Euler(Pitch, Yaw, 0);
    }

    void Movement()
    {
        Vector2 axis = new Vector2(Input.GetAxis("Vertical"), Input.GetAxis("Horizontal")) * WalkSpeed;
        Vector3 forward = new Vector3(-PlayerCamera.transform.right.z, 0.0f, PlayerCamera.transform.right.x);
        Vector3 wishDirection = (forward * axis.x + PlayerCamera.transform.right * axis.y + Vector3.up * RigidBody.velocity.y);
        RigidBody.velocity = wishDirection;
    }
}
