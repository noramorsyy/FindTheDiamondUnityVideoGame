using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class DestroyEnemy : MonoBehaviour
{
    public int health = 5;

    private void Update()
    {
        var ray = Camera.main.ScreenPointToRay(Input.mousePosition);
        RaycastHit hit;
        if (Input.GetMouseButtonDown(0) && Physics.Raycast(ray, out hit))
        {
            var selection = hit.transform;

            if (selection.gameObject.CompareTag("creeper"))
            {
                health -= 1;
                Debug.Log("Hit");

                if (health == 0)
                {
                    Destroy(gameObject);
                }
            }

        }

    }
}