using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Block : MonoBehaviour
{
    public GameObject DestroyBlockParticleSystem;

    public void DestroyBlock()
    {
        Destroy(gameObject);
        Instantiate(DestroyBlockParticleSystem, transform.position, Quaternion.identity);
    }
}
