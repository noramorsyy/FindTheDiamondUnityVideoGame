using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class Enderman : MonoBehaviour
{
    Transform target;
    public float MovementSpeed;
    public float TimeToGetAngry;
    public float TeleportationDelay;
    float timeStamp;
    bool angry = false;
    public Vector3 offset;
    float countdown;

    void Start()
    {
        target = GameObject.FindWithTag("Player").transform;
        countdown = TeleportationDelay;
    }

    void OnTriggerEnter(Collider playerDetected)
    {

        if (playerDetected.CompareTag("Player"))
        {
            transform.LookAt(target);
        }
    }


    void Update()
    {
        Vector3 targetPosition = new Vector3(target.position.x, transform.position.y, target.position.z);
        if (IsLookedAtByTarget())
        {
            Debug.Log("Player is looking at enemy.");
            timeStamp = Time.time;
            if(timeStamp >= TimeToGetAngry)
            {
                angry = true;
            }
        }
        else if (angry)
        {
            Debug.Log("Player is not looking at enemy."); 
            countdown -= Time.deltaTime;
            if(countdown <= 0f)
            {
               transform.position = target.transform.position + offset;
                countdown = 5f;
            }
        }
    }

    bool IsLookedAtByTarget()
    {
        Vector3 toEnderman = (this.transform.position - target.transform.position).normalized;
        float dot = Vector3.Dot(toEnderman, Camera.main.transform.forward);
        Debug.Log(dot);
        if (dot > 0.9f)
        {
            Debug.Log("Player is looking right at the enemy.");
            return true;
        }
        else
        {
            Debug.Log("Player is not looking at enemy.");
            return false;
        }
    }

}
