using UnityEngine;
using UnityEngine.SceneManagement;

public class Board : MonoBehaviour
{
    public int Size;
    public Camera Camera;
    public GameObject Block;
    public GameObject Diamond;
    public GameObject DestroyBlockParticleSystem;
    public string SelectableTag = "Selectable";
    public string diamondTag = "diamond";


    void Start()
    {
        CreateBoard();
        CreateDiamond();
        PlaceCamera();
    }

    // --------------------------------------------------------------------

    private void CreateBoard()
    {

        for(int i = 0; i < Size; i++)
        {
            for(int y = 0; y < Size; y++)
            {
                Instantiate(Block, new Vector3(i, 0, y), Quaternion.identity);
            }
        }
    }
    // --------------------------------------------------------------------

    private void PlaceCamera()
    {
        Camera.transform.position = new Vector3(Size / 2f - 0.5f, Size, -Size / 4f);
        Camera.transform.LookAt(new Vector3(Size / 2f - 0.5f, 0, Size / 2f));
    }

    // --------------------------------------------------------------------

    private void CreateDiamond()
    {
        var position = new Vector3(Random.Range(0, Size), 0, Random.Range(0, Size));
        Instantiate(Diamond, position, Quaternion.identity);

        GameObject.Destroy(GameObject.FindGameObjectWithTag("original")); // had to keep this because I kept finding two diamonds in the game
    }


    // --------------------------------------------------------------------


    private void Update()
    {
        var ray = Camera.ScreenPointToRay(Input.mousePosition);
        RaycastHit hit;
        if (Input.GetMouseButton(0) && Physics.Raycast(ray, out hit))
        {
            var selection = hit.transform;
            if (selection.CompareTag(SelectableTag))
            {
                Instantiate(DestroyBlockParticleSystem, hit.point, Quaternion.identity);
                Destroy(hit.transform.gameObject);
          
                            
            }

           if(selection.CompareTag(diamondTag))
           {
                Debug.Log("Diamond Found!");
                SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex + 1);
            }
        }

    }

}
