using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Creeper : MonoBehaviour
{

    void OnTriggerEnter(Collider PlayerDetected)
    {
        if (PlayerDetected.CompareTag("Player"))
        {
                int radius = 2;
                Collider[] HitColliders = Physics.OverlapSphere(transform.position, radius);

            foreach (Collider collider in HitColliders)
            {
                if(collider.tag == "Selectable")
                {
                    Destroy(collider.gameObject); //Destroys blocks
                    Destroy(this.gameObject); //Destroys Creeper
                }
                    
            }

        } 
    }

}
