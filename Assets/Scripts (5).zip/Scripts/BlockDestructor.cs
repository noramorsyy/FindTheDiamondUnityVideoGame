using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class BlockDestructor : MonoBehaviour
{
    public string SelectableTag = "Selectable";
    public GameObject DestroyBlockParticleSystem;
    public string DiamondTag = "diamond";

    private void Update()
    {
        var ray = Camera.main.ScreenPointToRay(Input.mousePosition);
        RaycastHit hit;
        if (Input.GetMouseButtonDown(0) && Physics.Raycast(ray, out hit))
        {
            var selection = hit.transform;
             if (selection.CompareTag(SelectableTag))
             {
                 Instantiate(DestroyBlockParticleSystem, hit.point, Quaternion.identity);
                 Destroy(hit.transform.gameObject);
             }
            if (selection.CompareTag(SelectableTag))
            {
                Instantiate(DestroyBlockParticleSystem, hit.point, Quaternion.identity);
                Destroy(hit.transform.gameObject);
            }
                if (selection.CompareTag(DiamondTag))
            {
                Debug.Log("Diamond Found!");
                SceneManager.LoadScene("PlayAgain");
            }
        }

    }
}
